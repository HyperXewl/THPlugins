﻿namespace Turbo.Plugins
{

    public interface IBanner
    {

        IWorldCoordinate FloorCoordinate { get; }

    }

}