﻿namespace Turbo.Plugins
{

    public enum ItemKind
    {
        loot,
        potion,
        healthglobe,
        powerglobe,
        rift_orb,
        uberstuff,
        gem,
        craft,
        goldcoin,
        book
    }

}