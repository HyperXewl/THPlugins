﻿namespace Turbo.Plugins
{

    public enum MapMode { Minimap, Map, PermaMap, WaypointMap, ActMap }

}