﻿namespace Turbo.Plugins
{

    public enum MonsterAffix: uint
    {
        Frozen = 4131130388,
        FrozenPulse = 1886876669,
        Arcane = 2625377780,
        Plagued = 2961013602,
        Waller = 481181063,
        Reflect = 2920375063,
        Vortex = 458872904,
        Wormhole = 1156956365,
        Electrified = 2542537664,
        Vampiric = 395423867,
        ExtraHealth = 2782485594,
        HealthLink = 1799201764,
        Knockback = 2206426855,
        Fast = 3775118,
        Desecrator = 4172983340,
        Molten = 106438735,
        Teleporter = 3787260902,
        Jailer = 4267280439,
        Shielding = 3569101591,
        FireChains = 3855260060,
        Nightmarish = 3049048382,
        Illusionist = 394214687,
        Poison = 1929212066,
        Mortar = 106654229,
        Orbiter = 1905614711,
        Thunderstorm = 4244410831,
        Avenger = 1165197192,
        Horde = 127452338,
        MissileDampening = 2882216553,
        Juggernaut = 3830498332,
    }

}