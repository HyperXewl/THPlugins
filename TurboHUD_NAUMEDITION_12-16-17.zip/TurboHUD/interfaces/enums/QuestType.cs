﻿namespace Turbo.Plugins
{

    public enum QuestType
    {
        MainQuest = 0,
        Event = 2,
        Challenge = 4,
        Bounty = 5,
        Unknown1 = 7,
        Unknown2 = 8,
        Unknown3 = 9,
    }

}