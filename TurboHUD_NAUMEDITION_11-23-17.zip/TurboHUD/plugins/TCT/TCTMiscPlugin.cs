//################################################################################
//# ..:: created with TCT Version 5.1 for THUD v7.2 (17.3.26.1) ::.. by RealGsus #
//################################################################################

using Turbo.Plugins.Default;

namespace Turbo.Plugins.TCT
{

    public class TCTMiscPlugin : BasePlugin, ICustomizer
    {

        public TCTMiscPlugin()
        {
            Enabled = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
        }

        public void Customize()
        {
            Hud.GetPlugin<NotifyAtRiftPercentagePlugin>().DisplayLimit = 100;
            // Hud.TogglePlugin<PortraitBottomStatsPlugin>(false);
            // Hud.TogglePlugin<NetworkLatencyPlugin>(false);
            // Hud.TogglePlugin<DamageBonusPlugin>(false);
            // Hud.TogglePlugin<GameInfoPlugin>(false);
            // Hud.TogglePlugin<TopExperienceStatistics>(false);
            // Hud.TogglePlugin<SkillRangeHelperPlugin>(false);
        }

    }

}
