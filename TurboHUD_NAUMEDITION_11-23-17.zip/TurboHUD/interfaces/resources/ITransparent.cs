﻿namespace Turbo.Plugins
{
    public interface ITransparent
    {
        float Opacity { get; set; }
    }
}