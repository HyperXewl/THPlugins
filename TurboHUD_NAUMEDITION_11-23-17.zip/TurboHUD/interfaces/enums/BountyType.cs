﻿namespace Turbo.Plugins
{

    public enum BountyType
    {
        None = -1,
        KillUnique = 0,
        KillBoss = 1,
        CompleteEvent = 2,
        ClearDungeon = 3,
        SpecialEvent = 4,
    }

}