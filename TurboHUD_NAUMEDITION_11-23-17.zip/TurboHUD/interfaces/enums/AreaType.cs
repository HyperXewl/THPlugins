﻿namespace Turbo.Plugins
{

    public enum AreaType { Normal, PvP, Disabled }

}