namespace Turbo.Plugins.Default
{
    public interface IItemRenderer
    {
        void RenderItem(IItem item, System.Drawing.RectangleF rect);
    }
}