namespace Turbo.Plugins.ZX
{
    using Turbo.Plugins.Default;
    using System.Linq;
    using System.Text;
    using System.Collections.Generic;

    public class NecromancerSkeletonIndicatorPlugin : BasePlugin, IInGameWorldPainter, IInGameTopPainter
    {
        public WorldDecoratorCollection CommandSkeletonDecorator, SkeletonMageDecorator;
        public TopLabelDecorator CommandSkeletonCountLabel, SkeletonMageCountLabel, CombinedSkeletonCountLabel;
        public string CommandSkeletonLabel, SkeletonMageLabel;
        public int CommandSkeletonCount, SkeletonMageCount;
        public float barW, barH, barX, barY, cmb_barW, cmb_barH, cmb_barX, cmb_barY;
        public bool CommandSkeletonEnabled, SkeletonMageEnabled, CombinedCountEnabled;

        private static uint CommandSkeletonSkillSNO = 453801;
        public HashSet<uint> CommandSkeletonActorSNOs = new HashSet<uint>
        {
            473147, // CommandSkeleton - No Rune
            473428, // CommandSkeleton - Enforcer
            473426, // CommandSkeleton - Frenzy
            473420, // CommandSkeleton - Dark Mending
            473417, // CommandSkeleton - Freezing Grasp
            473418  // CommandSkeleton - Kill Command
        };

        private static uint SkeletonMageSkillSNO = 462089;
        public HashSet<uint> SkeletonMageActorSNOs = new HashSet<uint>
        {
            472275, // Skeleton Mage - No Rune
            472588, // Skeleton Mage - Gift of Death
            472769, // Skeleton Mage - Contamination
            472801, // Skeleton Mage - Archer
            472606, // Skeleton Mage - Singularity
            472715  // Skeleton Mage - Life Support
        };


        public NecromancerSkeletonIndicatorPlugin()
        {
            Enabled = true;

            // Modify this to make the count combined
            CombinedCountEnabled = false;

            // Enable both indicator or disable the indicator a specific skill
            CommandSkeletonEnabled = true;
            SkeletonMageEnabled = true;

            // Inits variables
            CommandSkeletonCount = 0;
            SkeletonMageCount = 0;
            CommandSkeletonLabel = "";
            SkeletonMageLabel = "";
        }

        public override void Load(IController hud)
        {
            base.Load(hud);

            // Unlike the old XML system where it draws x,y,w,h in terms of percentage of screen size, the new plugin uses actual pixel coordinates
            // To convert x,y,w,h sizes from the XML system to the new plugin system, multiply the screensize with percentage. ie. XML size of 2 => 0.02f * screensize

            // Display coordinated for non-combined indicators
            barW = Hud.Window.Size.Width * 0.012f;
            barH = Hud.Window.Size.Height * 0.0175f;
            barX = Hud.Window.Size.Width * 0.475f;
            barY = Hud.Window.Size.Height * 0.36f;

            // Display coordinated for combined indicators
            cmb_barW = Hud.Window.Size.Width * 0.0175f;
            cmb_barH = Hud.Window.Size.Height * 0.0175f;
            cmb_barX = (Hud.Window.Size.Width * 0.5f) - (cmb_barW * 0.5f);
            cmb_barY = Hud.Window.Size.Height * 0.33f;

            // Decorator under each sekeleton melee
            CommandSkeletonDecorator = new WorldDecoratorCollection(
                new GroundCircleDecorator(Hud)
                {
                    Brush = Hud.Render.CreateBrush(240, 50, 200, 0, 1),
                    Radius = 0.5f,
                },
                new GroundLabelDecorator(Hud)
                {
                    BackgroundBrush = Hud.Render.CreateBrush(220, 200, 200, 0, 0),
                    TextFont = Hud.Render.CreateFont("tahoma", 7, 255, 255, 255, 255, true, false, false)
                },
                new MapShapeDecorator(Hud)
                {
                    ShapePainter = new RotatingTriangleShapePainter(Hud),
                    Brush = Hud.Render.CreateBrush(220, 200, 200, 0, 0),
                    Radius = 0f,
                    RadiusTransformator = new StandardPingRadiusTransformator(Hud, 250)
                }
            );

            // Decorator under each sekeleton mages
            SkeletonMageDecorator = new WorldDecoratorCollection(
                new GroundCircleDecorator(Hud)
                {
                    Brush = Hud.Render.CreateBrush(240, 200, 50, 0, 1),
                    Radius = 0.5f,
                },
                new GroundLabelDecorator(Hud)
                {
                    BackgroundBrush = Hud.Render.CreateBrush(220, 200, 200, 0, 0),
                    TextFont = Hud.Render.CreateFont("tahoma", 7, 255, 255, 255, 255, true, false, false)
                },
                new MapShapeDecorator(Hud)
                {
                    ShapePainter = new RotatingTriangleShapePainter(Hud),
                    Brush = Hud.Render.CreateBrush(220, 200, 200, 0, 0),
                    Radius = 0f,
                    RadiusTransformator = new StandardPingRadiusTransformator(Hud, 250)
                }
            );

            // Label Decorator for non-combined indicator
            CommandSkeletonCountLabel = new TopLabelDecorator(Hud)
            {
                TextFont = Hud.Render.CreateFont("tahoma", 7, 255, 255, 240, 0, false, false, false),
                BackgroundTexture1 = Hud.Texture.Button2TextureBrown,
                BackgroundTexture2 = Hud.Texture.BackgroundTextureOrange,
                BackgroundTextureOpacity2 = 0.25f
            };
            SkeletonMageCountLabel = new TopLabelDecorator(Hud)
            {
                TextFont = Hud.Render.CreateFont("tahoma", 7, 255, 255, 240, 0, false, false, false),
                BackgroundTexture1 = Hud.Texture.Button2TextureBrown,
                BackgroundTexture2 = Hud.Texture.BackgroundTextureOrange,
                BackgroundTextureOpacity2 = 0.25f
            };

            // Label Decorator for combined indicator
            CombinedSkeletonCountLabel = new TopLabelDecorator(Hud)
            {
                TextFont = Hud.Render.CreateFont("tahoma", 7, 255, 255, 240, 0, false, false, false),
                BackgroundTexture1 = Hud.Texture.Button2TextureBrown,
                BackgroundTexture2 = Hud.Texture.BackgroundTextureOrange,
                BackgroundTextureOpacity2 = 0.25f
            };
        }

        public void PaintWorld(WorldLayer layer)
        {
            // Don't draw if not playing a Necromancer; don't draw if is in town
            if (Hud.Game.Me.HeroClassDefinition.HeroClass != HeroClass.Necromancer || Hud.Game.IsInTown) return;

            // For Skeleton Melee, only when equipping the skill
            if (CommandSkeletonEnabled && Hud.Game.Me.Powers.UsedSkills.Where(x => x.SnoPower.Sno == CommandSkeletonSkillSNO) != null)
            {
                // Iterate all the game actors, find out and count which are skeleton melees summoned by player
                var CommandSkeletonActors = Hud.Game.Actors.Where(EachActor => CommandSkeletonActorSNOs.Contains(EachActor.SnoActor.Sno) && // Find out which are skeleton melees actors
                                            EachActor.SummonerAcdDynamicId == Hud.Game.Me.SummonerId); // Then find out if they are summoned by the player
                CommandSkeletonCount = CommandSkeletonActors.Count(); // And then count how many are found

                // Paint circle decorator under each skeleton melee 
                foreach (var EachActor in CommandSkeletonActors)
                {
                    var text = string.IsNullOrWhiteSpace(CommandSkeletonLabel) ? EachActor.SnoActor.NameLocalized : CommandSkeletonLabel;
                    CommandSkeletonDecorator.Paint(layer, EachActor, EachActor.FloorCoordinate, text);
                }
            }
            else
            {
                CommandSkeletonCount = 0;
            }

            // For Skeleton Mages, only when equipping the skill
            if (SkeletonMageEnabled && Hud.Game.Me.Powers.UsedSkills.Where(x => x.SnoPower.Sno == SkeletonMageSkillSNO) != null)
            {
                // Iterate all the game actors, find out and count which are skeleton mages summoned by player
                var SkeletonMageActors = Hud.Game.Actors.Where(EachActor => SkeletonMageActorSNOs.Contains(EachActor.SnoActor.Sno) && // Find out which are skeleton mages actors
                                         EachActor.SummonerAcdDynamicId == Hud.Game.Me.SummonerId); // Then find out if they are summoned by the player
                SkeletonMageCount = SkeletonMageActors.Count(); // And then count how many are found

                // Paint circle decorator under each skeleton melee
                foreach (var EachActor in SkeletonMageActors)
                {
                    var text = string.IsNullOrWhiteSpace(SkeletonMageLabel) ? EachActor.SnoActor.NameLocalized : SkeletonMageLabel;
                    SkeletonMageDecorator.Paint(layer, EachActor, EachActor.FloorCoordinate, text);
                }
            }
            else
            {
                SkeletonMageCount = 0;
            }
        }

        public void PaintTopInGame(ClipState clipState)
        {
            // Don't draw if not playing a Necromancer; don't draw if is in town
            if (Hud.Game.Me.HeroClassDefinition.HeroClass != HeroClass.Necromancer || Hud.Game.IsInTown) return;
            if (clipState != ClipState.BeforeClip) return;


            if (CombinedCountEnabled)
            {
                // Drawing for combined count indicator
                string CommandSkeletonCountText = (CommandSkeletonEnabled && CommandSkeletonCount != 0) ? CommandSkeletonCount.ToString() : "";
                string SkeletonMageCountText = (SkeletonMageEnabled && SkeletonMageCount != 0) ? SkeletonMageCount.ToString() : "";
                string ConcatText = (CommandSkeletonCountText != "" && SkeletonMageCountText != "") ? CommandSkeletonCountText + "+" + SkeletonMageCountText : CommandSkeletonCountText + SkeletonMageCountText;

                if (ConcatText != "")
                {
                    CombinedSkeletonCountLabel.TextFunc = () => ConcatText.ToString();
                    CombinedSkeletonCountLabel.Paint(cmb_barX, cmb_barY, cmb_barW, cmb_barH, HorizontalAlign.Center);
                }
            }
            else
            {
                // Drawing for non-combined count indicator
                if (CommandSkeletonEnabled && CommandSkeletonCount != 0)
                {
                    CommandSkeletonCountLabel.TextFunc = () => CommandSkeletonCount.ToString();
                    CommandSkeletonCountLabel.Paint(barX, barY, barW, barH, HorizontalAlign.Center);
                }

                if (SkeletonMageEnabled && SkeletonMageCount != 0)
                {
                    SkeletonMageCountLabel.TextFunc = () => SkeletonMageCount.ToString();
                    SkeletonMageCountLabel.Paint(Hud.Window.Size.Width - barX - barW, barY, barW, barH, HorizontalAlign.Center);
                }
            }
        }
    }
}