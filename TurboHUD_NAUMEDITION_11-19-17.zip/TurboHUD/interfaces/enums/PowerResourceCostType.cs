﻿namespace Turbo.Plugins
{

    public enum PowerResourceCostType
    {
        primary, secondary, hitpoint
    }

}
