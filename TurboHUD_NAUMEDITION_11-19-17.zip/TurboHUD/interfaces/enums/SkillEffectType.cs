﻿namespace Turbo.Plugins
{
    public enum SkillEffectType
    {
        meteor, wicked_wind, blizzard, acid_cloud, gargantuan, zombiedog, elite_wall, spike_trap, hydra, fetish, sentry, cota
    }
}