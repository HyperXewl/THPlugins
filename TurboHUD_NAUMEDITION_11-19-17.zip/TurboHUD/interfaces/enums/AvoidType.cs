﻿namespace Turbo.Plugins
{
    public enum AvoidType
    {
        Arcane, ArcaneSpawn, DemonMine, BeeWasp, WoodSpore, Desecrator, WoodEmitter, Molten, MoltenTrail, Poison, Orbiter, FrozenPulse,
        DemonicMeteor, FastmummyDeathPoison, BloodSpring, Droppod,
        PlagueCloud, PlagueHand, Mortar, IceBalls, DemonicForge, ExplodingGrotesque, OneHitMelee,
        Uber, Maghda, AzmodanFireball, AzmodanFireballExploded, AzmodanCorpses, GenericFire, GenericCold, GenericLightning, GenericPoison,
        RiftBossesForRangedClasses
    }
}