﻿namespace Turbo.Plugins.Default
{

    public enum ValueFormat { NormalNumber, NormalNumberNoDecimal, LongNumber, ShortNumber, AlwaysK, AlwaysKNoDecimal, AlwaysM, AlwaysMNoDecimal, LongTime, LongTimeNoSeconds }

}
