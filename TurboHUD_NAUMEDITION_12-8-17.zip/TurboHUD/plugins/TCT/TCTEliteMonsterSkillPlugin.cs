//################################################################################
//# ..:: created with TCT Version 5.1 for THUD v7.2 (17.3.26.1) ::.. by RealGsus #
//################################################################################

using Turbo.Plugins.Default;

namespace Turbo.Plugins.TCT
{

    public class TCTEliteMonsterSkillPlugin : BasePlugin, ICustomizer
    {

        public TCTEliteMonsterSkillPlugin()
        {
            Enabled = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
        }

        public void Customize()
        {
            Hud.GetPlugin<EliteMonsterSkillPlugin>().ArcaneDecorator.Enabled = false;
            Hud.GetPlugin<EliteMonsterSkillPlugin>().ArcaneSpawnDecorator.Enabled = false;
            Hud.GetPlugin<EliteMonsterSkillPlugin>().DesecratorDecorator.Enabled = false;
            Hud.GetPlugin<EliteMonsterSkillPlugin>().FrozenPulseDecorator.Enabled = false;
            Hud.GetPlugin<EliteMonsterSkillPlugin>().GhomDecorator.Enabled = false;
            Hud.GetPlugin<EliteMonsterSkillPlugin>().PlaguedDecorator.Enabled = false;
            Hud.GetPlugin<EliteMonsterSkillPlugin>().ThunderstormDecorator.Enabled = false;
        }

    }

}
