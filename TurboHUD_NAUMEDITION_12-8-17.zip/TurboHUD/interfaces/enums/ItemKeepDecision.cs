﻿namespace Turbo.Plugins
{
    public enum ItemKeepDecision
    {
        LooksGood,
        Irrelevant,
        DefinitelyBad,
    }
}