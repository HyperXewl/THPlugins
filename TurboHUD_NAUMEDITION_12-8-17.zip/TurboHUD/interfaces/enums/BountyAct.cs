﻿namespace Turbo.Plugins
{

    public enum BountyAct
    {
        None = -1,
        A1 = 0,
        A2 = 100,
        A3 = 200,
        A4 = 300,
        A5 = 400,
        OpenWorld = 3000,
        Test = 1000
    }

}