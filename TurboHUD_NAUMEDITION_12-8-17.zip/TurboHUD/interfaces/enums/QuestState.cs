﻿namespace Turbo.Plugins
{

    public enum QuestState { none = 0, started = 1, completed = 2 }

}