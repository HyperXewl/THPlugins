﻿namespace Turbo.Plugins
{

    public enum MonsterPriority
    {
        none,
        low,
        normal,
        high,
        goblin,
        keywarden,
        boss
    }

}