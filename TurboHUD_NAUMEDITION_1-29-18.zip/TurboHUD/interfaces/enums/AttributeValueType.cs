﻿namespace Turbo.Plugins
{

    public enum AttributeValueType
    {
        _float = 0,
        _int = 1
    }

}