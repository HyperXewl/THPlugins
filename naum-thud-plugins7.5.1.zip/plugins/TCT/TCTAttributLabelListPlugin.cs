//################################################################################
//# ..:: created with TCT Version 5.1 for THUD v7.2 (17.3.26.1) ::.. by RealGsus #
//################################################################################

using Turbo.Plugins.Default;

namespace Turbo.Plugins.TCT
{

    public class TCTAttributLabelListPlugin : BasePlugin, ICustomizer
    {

        public TCTAttributLabelListPlugin()
        {
            Enabled = true;
        }

        public override void Load(IController hud)
        {
            base.Load(hud);
        }

        public void Customize()
        {
            Hud.TogglePlugin<AttributeLabelListPlugin>(true);
        }

    }

}
