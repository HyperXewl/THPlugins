﻿namespace Turbo.Plugins
{
    public enum AvoidWeight
    {
        instadeath, bighit, bigdot, normal, low
    }
}