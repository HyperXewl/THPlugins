﻿namespace Turbo.Plugins
{
    public interface IGoldOnFloor: IActor
    {
    }
}