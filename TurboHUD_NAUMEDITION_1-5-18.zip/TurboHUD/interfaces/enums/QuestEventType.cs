﻿namespace Turbo.Plugins
{

    public enum QuestEventType
    {
        None = -1,
        TimedDungeon = 0,
        WaveFight = 1,
        Horde = 2,
        Zapper = 3,
        GoblinHunt = 4,
    }

}