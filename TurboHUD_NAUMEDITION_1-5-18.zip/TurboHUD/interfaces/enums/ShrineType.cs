﻿namespace Turbo.Plugins
{

    public enum ShrineType
    {
        BlessedShrine,
        EnlightenedShrine,
        FortuneShrine,
        FrenziedShrine,
        EmpoweredShrine,
        FleetingShrine,
        PowerPylon,
        ConduitPylon,
        ChannelingPylon,
        ShieldPylon,
        SpeedPylon,
        PoolOfReflection,
        BanditShrine,
        HealingWell
    }

}