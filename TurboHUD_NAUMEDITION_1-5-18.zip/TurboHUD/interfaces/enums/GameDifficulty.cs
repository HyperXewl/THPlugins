﻿namespace Turbo.Plugins
{

    public enum GameDifficulty
    {
        unknown = -1,
        n = 0,
        h = 1,
        e = 2,
        m = 3,
        t1 = 4,
        t2 = 5,
        t3 = 6,
        t4 = 7,
        t5 = 8,
        t6 = 9,
        t7 = 10,
        t8 = 11,
        t9 = 12,
        t10 = 13,
        t11 = 14,
        t12 = 15,
        t13 = 16,
    }

}
