﻿namespace Turbo.Plugins
{
    public interface IUiElement
    {
        string Path { get; }
        bool Visible { get; }
        System.Drawing.RectangleF Rectangle { get; }
    }
}
