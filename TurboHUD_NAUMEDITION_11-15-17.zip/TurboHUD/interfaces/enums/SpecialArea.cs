﻿namespace Turbo.Plugins
{

    public enum SpecialArea
    {
        None, Rift, GreaterRift, UberPortals, UberFight, PvP, ChallengeRiftHub, ChallengeRift
    }

}
